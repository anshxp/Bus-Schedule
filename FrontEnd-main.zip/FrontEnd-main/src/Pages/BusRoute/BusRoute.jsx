import './BusRoute.css';
import { useParams } from 'react-router-dom';
import Stop from '../../Components/Stop/Stop.jsx';
import { Container, Row } from 'react-bootstrap';
import Loading from '../../Components/Loading/Loading.jsx';
import { useState,useEffect } from 'react';

const BusRoute=()=>{
    const { busno } = useParams();
    console.log(busno);
    const [bus, setbus]= useState(null);
    const [loading, setLoading] = useState(true);
    useEffect(()=>{
        fetch(`http://localhost:3000/bus/buses/${busno}`)
        .then(res=> res.json())
        .then(data=>{
            console.log("Fetched Bus:", data);
            setbus(data || []);
            setLoading(false);
        })
        .catch(err => {
                console.error("Error fetching bus route:", err);
                setLoading(false);
            });
        }, [busno])
    if (loading) {
        return(
            <div className="load">
                <Loading />
            </div>
        ) 
    }
    if (!bus || !bus.stops) {
        console.log("No stops found for bus:", busno);
    }
    return (
        <Container className="mt-5 bus-route-container">
            <h3>Bus G{busno} Route</h3>
            <p>{bus.DriverName}</p>
            <p>{bus.ContactNo}</p>
            {bus.stops && bus.stops.map((stop, index) => (
                <Row className="stop" key={index}>
                <Stop
                    stopName={stop.stopName}
                    first={stop["1st_shift"] || "N/A"}
                    second={stop["2nd_shift"] || "N/A"}
                />
                </Row>
            ))}
        </Container>
    )
}
export default BusRoute;