import { useEffect, useState } from "react";
import SingleBus from "../../Components/SingleBus/SingleBus.jsx";
import { Container } from "react-bootstrap";
import {useNavigate} from "react-router-dom";
import Loading from "../../Components/Loading/Loading.jsx";
import { addRecentBuses } from "../../utills/RecentBuses";
import './AllBuses.css';
const AllBuses = () => {
  const [buses, setBuses] = useState([]);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    fetch("http://localhost:3000/bus/buses") 
      .then(res => res.json())
      .then(data => {
        console.log("Fetched buses:", data);
        setBuses(data);
        setLoading(false);
      })
      .catch(err => {
        console.error("Error fetching buses:", err);
        setLoading(false);
      });
  }, []);

  if (loading) {
    return(
        <div className="load">
            <Loading />
        </div>
    ) 
    }
  if (!buses.length) return <p>No buses found.</p>;
  return (
    <Container className="mt-5">
      <h2 className="mb-4">All The Available Buses</h2>
      <div className="bus-list">
        {buses.map((bus,idx)=>(
            <SingleBus 
              key={idx}
              onClick={()=>{
                  addRecentBuses(bus);
                  navigate(`/bus/${bus.Busno}`)
                }}
              busNumber={bus.Busno}
              driverName={bus.DriverName}
              mobile={bus.ContactNo}
            />
        ))}
      </div>
    </Container>
  );
};

export default AllBuses;
