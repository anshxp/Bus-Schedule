import './Stop.css';
import { Container, Col,Row } from 'react-bootstrap';
const Stop=({stopName,first,second})=>{
    return (
        <Container className="mt-5 stop-container">
            <Row>
                <Col className="stop-name">{stopName}</Col>
                <Col className="stop-time">{first}</Col>
                <Col className="stop-time">{second}</Col>
            </Row>
        </Container>
    )
}
export default Stop;