import { Container } from "react-bootstrap"
import './SingleBus.css';
import { useNavigate } from "react-router-dom";

const SingleBus=({busNumber,driverName,mobile,onClick})=>{
    const navigate = useNavigate();
    return(
        <Container className="mt-5 single-bus">
                <div onClick={onClick} className="bus-detail" style={{ cursor: "pointer" }}>
                    <h3 className="mb-4 busn">G{busNumber}</h3>
                    <div className="details">
                        <p className="dName">{driverName}</p>
                        <p className="dMobile">{mobile?mobile:"Not Available"}</p>
                    </div>
                </div>
        </Container>
    )
}

export default SingleBus;