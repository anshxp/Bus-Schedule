import { getRecentBuses } from '../../utills/RecentBuses';
import { useEffect,useState } from 'react';
import './RecentBuses.css';
import { addRecentBuses } from '../../utills/RecentBuses';
import { useNavigate } from 'react-router-dom';
import SingleBus from '../SingleBus/SingleBus';
const RecentBuses=()=>{
    const navigate = useNavigate();
    const [recentbuses,setrecentbuses]=useState([]);
    useEffect(()=>{
        setrecentbuses(getRecentBuses());
    },[]);
    return(
        <div className="recent-buses mt-3">
            <h4>Recent Buses</h4>
            {recentbuses.length===0?(
                <p className="no-recent">No recent buses found</p>
            ):(
                <ul className="recent-bus-list">
                    {recentbuses.map((bus, index) => (
                        <li key={index}>
                        <SingleBus 
                            onClick={()=>{
                                    addRecentBuses(bus);
                                    navigate(`/bus/${bus.Busno}`)
                                }}
                            busNumber={bus.Busno}
                            driverName={bus.DriverName}
                            mobile={bus.ContactNo}/>
                        </li>
                    ))}
                </ul>
            )}
        </div>
    )
}
export default RecentBuses;